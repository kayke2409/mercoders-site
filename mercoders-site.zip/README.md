# Mercoders Site

Site institucional da Mercoders, criado com Next.js + TailwindCSS.

## Scripts

- `npm run dev` — roda o site localmente
- `npm run build` — build de produção
- `npm run start` — inicia o site em produção
