export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-black text-yellow-400">
      <h1 className="text-5xl font-bold">Bem-vindo à Mercoders</h1>
    </div>
  );
}
